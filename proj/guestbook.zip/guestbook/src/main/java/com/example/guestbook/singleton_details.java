package com.twilio;
import java.io.*;
public class singleton_details implements java.io.Serializable {
}